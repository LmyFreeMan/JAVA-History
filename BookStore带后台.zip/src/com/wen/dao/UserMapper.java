package com.wen.dao;


import org.springframework.stereotype.Repository;

import com.wen.entity.User;

@Repository
public interface UserMapper {
	
	//登录验证
	public User login(String name,String pass);
	
	//新增账户
	public int insert(User u);
}
