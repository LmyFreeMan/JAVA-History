package com.wen.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.wen.entity.Book;
import com.wen.entity.Cart;
import com.wen.entity.Message;
import com.wen.entity.Orderitem;
import com.wen.entity.Orders;
import com.wen.entity.Type;

@Repository
public interface BookMapper {
	
	//查询图书种类
	public List<Type> findAllType();
	
	//查询精选图书	
	public List<Book> findJingxuan();
	
	//查询最新图书 
	public List<Book> findNewbook();
	
	//查询三本折扣书籍
	public List<Book> findZKbook();
	
	//查询一本书
	public Book getBook(int id);
	
	//查询相关图书
	public List<Book> findBook(int typeId);
	
	//查询所有图书
	public List<Book> findAllBook();
	
	//查询所有折扣图书
	public List<Book> findAllZKbook();
	
	//加入购物车
	public int addCart(Cart cart);
	
	//查询对应订单
	public Cart getOneCart(int userId,int bookId);
	
	//更新又一次加入购物车
	public int update(int number);
	
	//插入订单详细信息
	public int insertOrderitem(List<Orderitem> list);
	
	//根据Userid删除购物车记录
	public int deleteCartByuserid(int userId);
	
	//根据userid和zhuangtai查询订单
	public List<Orders> findOrderbyuserid(int userId);
	
	//查询订单详细信息<orderid>
	public List<Orderitem> findOrderitem(int orderId);
	
	//查询某一用户的购物车
	public List<Cart> getCartByUserId(int id);
	
	//提交一个订单
	public int insertOrder(Orders o);
	
	//查询最大订单Id号
	public int MaxOrderId();
	
	//查询最大回复ID号
	public int MaxReplyId();
	
	//插入一条回复
	public int insertReply(Message s);
}
