package com.wen.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.wen.entity.*;

@Repository
public interface AdminMapper {
	
	//登录验证
	public User dologinadmin(String name,String pass);
	
	//查询所有图书信息
	public List<Book> findAllBook();
	
	//查询所有的图书种类
	public List<Type> findAlltype();
	
	//根据ID查询一本书
	public Book findByid(int id);
	
	//分页
	public List<Book> findAllBookFy(int start,int psize);
	
	//关键字查询
	public List<Book> findByKey(String key);
	
	//用户关键字查询
	public List<User> findByuserKey(String key);
	
	//修改图书
	public int updateBook(Book book);
	
	//查询最大图书ID号
	public int findMaxbookid();
	
	//新增一本书
	public int insert(Book book);
	
	//删除一本书
	public int deleteBook(int id);
	
	//查询所有用户 
	public List<User> findUser();
	
	//用户分页
	public List<User> findAllUserFy(int start,int psize);
	
	//删除一个用户
	public int deleteUser(int id);
	
	//查询一个用户
	public User findByuserid(int id);
	
	//修改用户
	public int updateuser(User user);
	
	//查询订单
	public List<Orders> getAllOrder();
	
	public List<Orders> getAllOrderFY(int start,int psize);
	
	//查询详情订单
	public List<Orderitem> finditembyorderId(int id);
	
	//处理订单
	public int chuli(String zhuangtai,int id);
	
	//删除订单
	public int deleteorder(int id);
	
	//删除订单里面的详细订单
	public int deleteOrderitem(int OrderId);
	
	//删除图书种类
	public int deletetype(int id);
	
	//查询最大TypeId号
	public int findMaxtypeid();
	
	//插入图书种类
	public int insertType(Type type);
	
	//查询一个图书种类typeId
	public Type findBytypeid(int id);
	
	//查询一个图书种类是否存在
	public Type findBytypename(Type type);
	
	//修改图书种类
	public int updatetype(Type type);
	
	//查询所有留言
	public List<Message> findAllmessage();
	
	//删除留言信息
	public int deletemessage(int id);
	
	//根据Id查询某一条回复
	public Message getByidreply(int id);
	
	//添加回复，即修改
	public int addreply(String reply,int id);
	
	//留言关键字查询
	public List<Message> findBymessageKey(String key);
}
