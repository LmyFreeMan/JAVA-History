package com.wen.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wen.dao.AdminMapper;
import com.wen.entity.*;

@Controller
public class AdminController {
	
	@Autowired
	private AdminMapper adminMapper;
	
	@RequestMapping("adminlogin.do")
	public String login(String name,String password,Model model){
		User user = adminMapper.dologinadmin(name, password);
		if(user!=null){
			if(user.getIsadmin()==1){
				return "admin/admin";
			}else{
				model.addAttribute("msg", "您不是管理员身份！");
				return "admin/login";
			}
		}else{
				model.addAttribute("msg", "用户名或密码错误！");
				return "admin/login";
			}
		}

	@RequestMapping("book.do")
	public String findAllBook(String pnos,Model model){
		List<Book> blist = adminMapper.findAllBook();
		
		//分页
		if(pnos==null){
			pnos="1";
		}
		int pno = Integer.parseInt(pnos);
		int psize = 5;
		int start = (pno-1)*psize;
		List<Book> blist2 = adminMapper.findAllBookFy(start, psize);
		int pcount = (blist.size()+psize-1)/5;
		model.addAttribute("pcount", pcount);
		model.addAttribute("pno", pno);
		model.addAttribute("blist", blist2);
		List<Type> tlist = adminMapper.findAlltype();
		model.addAttribute("tlist", tlist);
		
		return "admin/book";
	}
	
	@RequestMapping("deletebook.do")
	public String deleteBook(int id,Model model){
		adminMapper.deleteBook(id);
		
		return "redirect:/book.do";
	}
	
	@RequestMapping("search.do")
	public String findByKey(String key,Model model){
		List<Book> blist = adminMapper.findByKey("%"+key+"%");
		model.addAttribute("blist", blist);
		return "admin/book";
	}
	
	@RequestMapping("searchuser.do")
	public String findbyuserkey(String key,Model model){
		List<User> ulist = adminMapper.findByuserKey("%"+key+"%");
		model.addAttribute("ulist", ulist);
		return "admin/user";
	}
	
	@RequestMapping("bookInsert.do")
	public String maxBookId(Model model){
		int id = adminMapper.findMaxbookid();
		model.addAttribute("id", id+1);
		List<Type> tlist = adminMapper.findAlltype();
		model.addAttribute("tlist", tlist);
		return "admin/bookInsert";
	}
	
	@RequestMapping("addbook.do")
	public String addbook(Book book){
		adminMapper.insert(book);
		
		return "redirect:/book.do";
	}
	
	@RequestMapping("updatebook.do")
	public String updateBook(int id,Model model){
		Book book2 = adminMapper.findByid(id);
		model.addAttribute("book2", book2);
		List<Type> tlist = adminMapper.findAlltype();
		model.addAttribute("tlist", tlist);
		return "admin/bookUpdate";
	}
	
	@RequestMapping("updatebook2.do")
	public String updateBook2(Book book,Model model){
		adminMapper.updateBook(book);
		
		return "redirect:/book.do";
	}
	
	@RequestMapping("user.do")
	public String findUser(String pnos,Model model){
		List<User> ulist = adminMapper.findUser();
		//分页
		if(pnos==null){
			pnos="1";
		}
		int pno = Integer.parseInt(pnos);
		int psize = 5;
		int start = (pno-1)*psize;
		List<User> ulist2 = adminMapper.findAllUserFy(start, psize);
		int pcount = (ulist.size()+psize-1)/5;
		model.addAttribute("pcount", pcount);
		model.addAttribute("pno", pno);
		model.addAttribute("ulist", ulist2);
		return "admin/user";
	}
	
	@RequestMapping("deleteuser.do")
	public String deleteUser(int id,Model model){
		adminMapper.deleteUser(id);
		
		return "redirect:/user.do";
	}
	
	@RequestMapping("updateuser.do")
	public String updateuser(int id,Model model){
		User user = adminMapper.findByuserid(id);
		model.addAttribute("user", user);
		return "admin/userUpdate";
	}
	
	@RequestMapping("adduser.do")
	public String user(User user){
		adminMapper.updateuser(user);
		return "redirect:/user.do";
	}

	@RequestMapping("orders.do")
	public String getAllOrder(String pnos,Model model){
		List<Orders> olist = adminMapper.getAllOrder();
		List<Orderitem> itemlist = null;
		//分页
		if(pnos==null){
			pnos="1";
		}
		int pno = Integer.parseInt(pnos);
		int psize = 5;
		int start = (pno-1)*psize;
		List<Orders> olist2 = adminMapper.getAllOrderFY(start, psize);
		int pcount = (olist.size()+psize-1)/5;
		for(Orders o:olist2){
			itemlist = adminMapper.finditembyorderId(o.getId());
			o.setItemlist(itemlist);
		}
		
		model.addAttribute("pcount", pcount);
		model.addAttribute("pno", pno);
		model.addAttribute("olist", olist2);
		return "admin/order";
	}

	@RequestMapping("chuli.do")
	public String chuli(int id){
		adminMapper.chuli("Y", id);
		return "redirect:/orders.do";
	}
	
	@RequestMapping("deleteorder.do")
	public String deleteorder(int id,Model model){
		adminMapper.deleteorder(id);
		adminMapper.deleteOrderitem(id);
		return "redirect:/orders.do";
	}
	
	@RequestMapping("type.do")
	public String type(Model model){
		List<Type> tlist = adminMapper.findAlltype();
		model.addAttribute("tlist", tlist);
		return "admin/type";
	}
	
	@RequestMapping("deletetype.do")
	public String deletetype(int id){
		adminMapper.deletetype(id);
		return "redirect:/type.do";
	}
	
	@RequestMapping("typeInsert.do")
	public String typeInsert(Model model){
		int id = adminMapper.findMaxtypeid();
		model.addAttribute("id", id+1);
		return "admin/typeInsert";
	}
	
	@RequestMapping("addtype.do")
	public String addtype(Type type,Model model){
		Type type1 = adminMapper.findBytypename(type);
		if(type1==null){
			adminMapper.insertType(type);
			return "redirect:/type.do";
		}else{
			model.addAttribute("send", "图书种类名已存在！！");
			return "admin/typeInsert";
		}
	}
	
	@RequestMapping("updatetype.do")
	public String updatetype(int id,Model model){
		Type type = adminMapper.findBytypeid(id);
		model.addAttribute("type", type);
		return "admin/typeUpdate";
	}
	
	@RequestMapping("typeupdate.do")
	public String typeupdate(Type type,Model model){
		Type type1 = adminMapper.findBytypename(type);
		if(type1==null){
			adminMapper.updatetype(type);
			return "redirect:/type.do";
		}else{
			model.addAttribute("send", "图书种类名已存在！！");
			return "admin/typeUpdate";
		}
	}
	
	@RequestMapping("message.do")
	public String Message(Model model){
		List<Message> mlist = adminMapper.findAllmessage();
		model.addAttribute("mlist", mlist);
		return "admin/message";
	}
	
	@RequestMapping("deletemessage.do")
	public String deleteMessage(int id){
		adminMapper.deletemessage(id);
		return "redirect:/message.do";
	}
	
	@RequestMapping("messagereply.do")
	public String messageReply(int id,Model model){
		Message message = adminMapper.getByidreply(id);
		model.addAttribute("message", message);
		return "admin/reply";
	}
	
	@RequestMapping("addreply.do")
	public String addreply(int id,String reply){
		adminMapper.addreply(reply, id);
		return "redirect:/message.do";
	}
	
	@RequestMapping("searchmessage.do")
	public String searchmessage(String key,Model model){
		List<Message> mlist = adminMapper.findBymessageKey("%"+key+"%");
		model.addAttribute("mlist", mlist);
		return "admin/message";
	}
}
