package com.wen.web;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wen.dao.BookMapper;
import com.wen.dao.UserMapper;
import com.wen.entity.Book;
import com.wen.entity.Cart;
import com.wen.entity.Message;
import com.wen.entity.Orderitem;
import com.wen.entity.Orders;
import com.wen.entity.Type;
import com.wen.entity.User;

@Controller
public class BookController {
	
	@Autowired
	private BookMapper bookMapper;
	@Autowired
	private UserMapper userMapper;
	
	@RequestMapping("/index.do")
	public String Type(Model model,HttpSession session){
		List<Type> typelist = bookMapper.findAllType();
		session.setAttribute("typelist", typelist);
		
		List<Book> jxlist = bookMapper.findJingxuan();
		model.addAttribute("jxlist", jxlist);
		
		List<Book> zxlist = bookMapper.findNewbook();
		model.addAttribute("zxlist", zxlist);
		
		List<Book> zklist = bookMapper.findZKbook();
		session.setAttribute("zklist", zklist);
		
		return "index";
	}
	
	@RequestMapping("details.do")
	public String getBook(Model model,int id){
		
		Book book = bookMapper.getBook(id);
		model.addAttribute("book", book);
		
		List<Book> xglist = bookMapper.findBook(book.getTypeId());
		for(int i=0;i<xglist.size();i++){
			if(xglist.get(i).getId()==book.getId()){
				xglist.remove(i);
			}
		}
		model.addAttribute("xglist", xglist);
		return "details";
	}
	
	@RequestMapping("category.do")
	public String findAllBook(Model model){
		List<Book> booklist = bookMapper.findAllBook();
		model.addAttribute("booklist", booklist);
		return "category";
	}
	
	@RequestMapping("/specials.do")
	public String findAllZKbook(Model model){
		List<Book> zkall = bookMapper.findAllZKbook();
		model.addAttribute("zkall", zkall);
		return "specials";
	}
	
	@RequestMapping("/login.do")
	public String login(String name,String pass,Model model,HttpSession session){
		if(name!=null&&pass!=null){
			User u  = userMapper.login(name, pass);
			if(u!=null){
				session.setAttribute("loginuser", u);
				//查询购物车信息
				double sum = 0.0;
				int countCart =  0;
				List<Cart> list = bookMapper.getCartByUserId(u.getId());
				double acc;
				for(Cart c:list){
					acc=0;
					countCart++;
					acc = c.getBook().getPrice()*c.getNumber();
					sum+=acc;
					c.setTotalprice(acc);
				}
				session.setAttribute("countCart", countCart);
				session.setAttribute("sum", sum);
				return "redirect:/index.do";
			}else{
				return "error";
			}
		}else{
			return "error";
		}
	}
	
	@RequestMapping("/exit.do")
	public String exit(HttpSession session){
		session.removeAttribute("loginuser");
		return "redirect:/index.do";
	}
	
	@RequestMapping("/register.do")
	public String insert(User user,Model model){
		
		userMapper.insert(user);
		
		return "myaccount";
	}
	
	@RequestMapping("/addcart.do")
		public String addcart(String num,int bookid,HttpSession session,Model model){
			User u = (User)session.getAttribute("loginuser");
			if(u!=null){
				Book book = new Book();
				book = bookMapper.getBook(bookid);
				List<Cart> list = bookMapper.getCartByUserId(u.getId());
				if(bookMapper.getOneCart(u.getId(), bookid)==null){
						Cart cart = new Cart();
						cart.setBookId(bookid);
						cart.setUserId(u.getId());
						cart.setNumber(Integer.parseInt(num));
						bookMapper.addCart(cart);
					}else{
						Cart cart = new Cart();
						cart = bookMapper.getOneCart(u.getId(), bookid);
						int number = cart.getNumber()+Integer.parseInt(num);
						bookMapper.update(number);
					}
				return "redirect:/carts.do";
			}else{
				model.addAttribute("msg", "请先登录！");
				return "myaccount";
			}
		}
	
	@RequestMapping("/carts.do")
	public String carts(HttpSession session,Model model){
		User u = (User)session.getAttribute("loginuser");
		int countCart = 0;
		if(u!=null){
			double sum = 0;
			List<Cart> list = bookMapper.getCartByUserId(u.getId());
			double acc;
			for(Cart c:list){
				acc=0;
				countCart++;
				acc = c.getBook().getPrice()*c.getNumber();
				sum+=acc;
				c.setTotalprice(acc);
			}
			model.addAttribute("cartlist", list);
			session.setAttribute("countCart", countCart);
			session.setAttribute("sum", sum);
			return "cart";
		}else{
			model.addAttribute("msg", "请先登录！");
			return "myaccount";
		}
	}
	//提交订单
	@RequestMapping("/order.do")
	public String order(Double sum,HttpSession session){
		User u = (User)session.getAttribute("loginuser");
		
		//获取系统时间
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		Date today = new Date();
		String time = sf.format(today);
		
		Orders o = new Orders();
		o.setUserId(u.getId());
		o.setOrderTime(time);
		o.setTotalprice(sum);
		o.setZhuangtai("N");
		bookMapper.insertOrder(o);
		
		//插入订单详情
		int orderid = bookMapper.MaxOrderId();
		List<Orderitem> olist = new ArrayList<Orderitem>();
		List<Cart> list = bookMapper.getCartByUserId(u.getId());
		Orderitem or = null;
		for(Cart c:list){
			or = new Orderitem();
			or.setOrderId(orderid);
			or.setBookId(c.getBookId());
			or.setBookNum(c.getNumber());
			olist.add(or);
		}
		bookMapper.insertOrderitem(olist);
		
		//删除该用户购物车记录
		bookMapper.deleteCartByuserid(u.getId());
		return "redirect:/orderitem.do";
	}
	
	@RequestMapping("orderitem.do")
	public String orderItem(Model model,HttpSession session){
		User u = (User)session.getAttribute("loginuser");
		if(u!=null){
			int userid = u.getId();
			List<Orders> orders = bookMapper.findOrderbyuserid(userid);
			if(orders.size()>0){
				//得到最新的Order
				Orders o=orders.get(orders.size()-1);
				model.addAttribute("orders", o);
				
				List<Orderitem> itemlist = bookMapper.findOrderitem(o.getId());
				
				
				model.addAttribute("itemlist", itemlist);
				return "order";
			}else{
				model.addAttribute("noorder", "您目前没有订单，赶快下单吧！");
				return "order";
			}
		}else{
			model.addAttribute("msg", "请先登录！");
			return "myaccount";
		}
	}
	
	@RequestMapping("reply.do")
	public String findReplyID(Model model){
		int id = bookMapper.MaxReplyId();
		model.addAttribute("id", id+1);
		return "contact";
	}
	
	
	@RequestMapping("contact.do")
	public String reply(Message message,Model model){
		bookMapper.insertReply(message);
		model.addAttribute("msg", "恭喜您，回复成功!!");
		return "contact";
	}
}
