package com.wen.entity;

import java.util.List;

public class Orders {
	private int id;
	private int userId;
	private double totalprice;
	private String orderTime;
	private String zhuangtai;
	private User user;
	List<Orderitem> itemlist;
	
	
	public List<Orderitem> getItemlist() {
		return itemlist;
	}
	public void setItemlist(List<Orderitem> itemlist) {
		this.itemlist = itemlist;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
	public String getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	
	
}
