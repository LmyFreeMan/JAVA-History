/*
Navicat MySQL Data Transfer

Source Server         : hh
Source Server Version : 50173
Source Host           : localhost:3306
Source Database       : books

Target Server Type    : MYSQL
Target Server Version : 50173
File Encoding         : 65001

Date: 2019-05-07 17:04:21
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `author` varchar(20) DEFAULT NULL,
  `publisher` varchar(30) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `images` varchar(50) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `publishtime` datetime DEFAULT NULL,
  `uptime` datetime DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `tuijian` varchar(2) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO book VALUES ('1', '我遇到你', '9', '敬一丹', '长江文艺出版社', '9787535479914', '39.8', 'bookimages/1.jpg', '5', '2015-05-01 00:00:00', '2015-06-05 00:00:00', '10', 'Y', '今年4月，60岁的敬一丹从央视退休，写下回忆性文字，回顾自己在央视“焦点访谈”“感动中国”“一丹话题”等的历程，这个历程也是见证中国百姓共同关心的重大事件的历程。本书还包括敬一丹在全国各地采访做节目刻骨铭心的经历，生动叙述了遇到各层面百姓、央视共事的工作伙伴等经历，故事真实生动，思考和感受刻骨铭心。　');
INSERT INTO book VALUES ('2', '你是人间的四月天', '9', '林徽因', '北京联合出版公司', '9787201088938', '48', 'bookimages/2.jpg', '3', '2014-10-01 00:00:00', '2015-01-02 00:00:00', '10', 'N', '《你是人间的四月天：林徽因作品全集》盒装全二册，还原真实的林徽因及她的黄金时代。\r\n　　根据原载整理成文，杰出建筑学家、作家、诗人林徽因，治学、作文、写诗的真实人生。');
INSERT INTO book VALUES ('3', '神奇校车·图画书版（全11册） ', '2', '【美】乔安娜柯尔　著 [美]', '贵州人民出版社', '21005473', '132', 'bookimages/3.jpg', '6', '2011-01-01 00:00:00', '2012-10-01 00:00:00', '8', 'Y', '由于这套书故事情节离奇而夸张，天马行空的想象与画面的表达相得益彰，注定这是一套热闹而好玩的书。为了让故事、画面与人物协调，我们下功夫对人物的语言进行了推敲，尽量还原人物对话的幽默感，更生动地展示出人物的性格；');
INSERT INTO book VALUES ('4', '新华字典（第11版）', '7', '中国社会科学院语言研究所', '商务印书馆', '9787100077040', '24', 'bookimages/xinhuazidian.jpg', '15', '2011-06-01 00:00:00', '2011-10-08 00:00:00', '7', 'N', '帮助几亿中国人民扫盲识字。《新华字典》自1953 年出版以来，成为亿万群众读书识字、学习文化的良师益友，为我国的全民教育、文化普及起到了十分重大的作用。');
INSERT INTO book VALUES ('5', '最新C语言程序设计教程 ', '5', '刘正林，谢永锋，祝宏', '华中科技大学出版社', '9787550240964', '39.8', 'bookimages/C.jpg', '3', '2006-09-01 00:00:00', '2008-10-09 00:00:00', '8.5', 'Y', '本书按照“循序渐进、突出重点、深人浅出、融会贯通”的教学原则编写，并以全国计算机等级考试中的C和c++两个科目作为参照体系。每章都有小结，归纳出必须掌握的重点内容，并附有大量的习题，以加深读者对重点内容的理解。\r\n');
INSERT INTO book VALUES ('6', '没拼过的青春，不值一过', '9', '邓楚涵', '北京联合出版公司', '9787550240964', '29.8', 'bookimages/3.jpg', '6', '2014-12-01 00:00:00', '2015-03-08 00:00:00', '7.2', 'Y', '邓楚涵的人生履历，和他的脸一样完美无瑕。\r\n 他在智力上碾杀一切。《天才知道》荣耀登顶，美国土木竞赛冠军，顶尖大学全才学子，国奖上奖收入囊中……他说，成功在于，当别人放弃时，你多忍了一分钟。\r\n');
INSERT INTO book VALUES ('7', '互联网思维到底是什么', '4', '项建标, 蔡华, 柳荣军', '电子工业出版社', '9787121227295', '49', 'bookimages/hulianwangsiwei.jpg', '8', '2014-04-01 00:00:00', '2014-09-03 00:00:00', '6.1', 'N', '本书基于丰富的行业案例与实战积累，首度在《互联网思维到底是什么——移动浪潮下的新商业逻辑》中提出：互联网思维是相对于工业化思维而言的，它创造了一个新的生态系统，开启了一个新的时代。这个时代是去中心、异质、多元和感性的。在互联网思维的指导下，扁平化的企业组织、强烈的情感诉求，以及自传播的媒体属性，让产品本身成为一个有机生命体。');
INSERT INTO book VALUES ('8', '养脾胃就是养命 ', '3', '翟煦', '江西科学技术出版社', '9787539052540', '30', 'bookimages/yangpipeijiushiyangming.jpg', '4', '2015-03-01 00:00:00', '2015-04-03 00:00:00', '10', 'N', '经常便秘、口臭难闻、吃饭不香、晚上睡不好？这些都是脾胃问题惹的祸。由于工作压力大、饮食不规律不卫生等原因，越来越多的中国人脾胃都出了毛病。“三分治、七分养”，权威专家告诉你通过简单的饮食调养、运动锻炼、按摩穴位、调节情绪等，就能远离脾胃疾病。');
INSERT INTO book VALUES ('9', '人生哲思录(修订版) ', '1', '周国平', '上海辞书出版社', '9787532627721', '31', 'bookimages/renshengzhesilu.jpg', '5', '2011-05-01 00:00:00', '2015-01-01 00:00:00', '10', 'Y', '《人生哲思录》的性质介于辞典和文摘之间，内容是周国平的文字的一个摘录，形式是像辞典那样按照主题和关键词加以详细分类。编选过程是这样的：首先，作者把自己迄今为止已出版的和未出版的全部非学术性质的文字通读一遍，从中摘出自己认为比较有价值并且可以独立存在的句子或段落');

-- ----------------------------
-- Table structure for `cart`
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `bookId` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO cart VALUES ('8', '4', '7', '2');
INSERT INTO cart VALUES ('9', '4', '6', '1');

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `reply` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO message VALUES ('1', 'boya', '1123324232', 'ddddddddddddddddddddddddddddgewerwersfsdfsa', '河北');
INSERT INTO message VALUES ('2', 'boya', '1123324232', 'ddddddddddddddddddddddddddddgewerwersfsdfsa', '河北师范大学河北师范大学河北师范大学');
INSERT INTO message VALUES ('3', 'saa', 'aa', '河北师范大学河北师范大学河北师范大学河北师范大学河北师范大学河北师范大学', '河北师范大学河北师范大学河北师范大学');

-- ----------------------------
-- Table structure for `orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) DEFAULT NULL,
  `bookId` int(11) DEFAULT NULL,
  `bookNum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO orderitem VALUES ('15', '10', '2', '2');
INSERT INTO orderitem VALUES ('16', '10', '3', '1');
INSERT INTO orderitem VALUES ('17', '10', '1', '1');
INSERT INTO orderitem VALUES ('18', '11', '6', '1');
INSERT INTO orderitem VALUES ('19', '12', '6', '1');
INSERT INTO orderitem VALUES ('20', '12', '8', '1');
INSERT INTO orderitem VALUES ('21', '13', '2', '2');
INSERT INTO orderitem VALUES ('22', '13', '3', '1');
INSERT INTO orderitem VALUES ('23', '13', '1', '1');
INSERT INTO orderitem VALUES ('24', '14', '4', '1');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `totalprice` double DEFAULT NULL,
  `orderTime` datetime DEFAULT NULL,
  `zhuangtai` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO orders VALUES ('10', '1', '267.8', '2015-05-19 11:13:00', 'N');
INSERT INTO orders VALUES ('11', '3', '29.8', '2015-05-19 11:27:00', 'N');
INSERT INTO orders VALUES ('12', '3', '59.8', '2015-05-19 11:30:00', 'N');
INSERT INTO orders VALUES ('13', '1', '267.8', '2015-05-19 11:46:00', 'N');
INSERT INTO orders VALUES ('14', '1', '24', '2019-05-07 03:52:00', 'N');

-- ----------------------------
-- Table structure for `type`
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO type VALUES ('1', '社科');
INSERT INTO type VALUES ('2', '童书');
INSERT INTO type VALUES ('3', '生活');
INSERT INTO type VALUES ('4', '经管');
INSERT INTO type VALUES ('5', '计算机');
INSERT INTO type VALUES ('6', '教育');
INSERT INTO type VALUES ('7', '工具书');
INSERT INTO type VALUES ('8', '励志');
INSERT INTO type VALUES ('9', '文学');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `truename` varchar(10) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `isadmin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO user VALUES ('1', 'sophia', 'sophia', '张薇', 'sophia@163.com', '13201012233', '汇华学院', '信息工程学部2012计算机', '0');
INSERT INTO user VALUES ('2', 'admin', 'admin', null, null, null, null, null, '1');
INSERT INTO user VALUES ('3', 'boya', 'boya', null, null, null, null, null, '0');
INSERT INTO user VALUES ('4', 'eve', 'eve', null, null, null, null, null, '0');
INSERT INTO user VALUES ('9', 'haha', 'haha', null, null, null, null, null, null);
